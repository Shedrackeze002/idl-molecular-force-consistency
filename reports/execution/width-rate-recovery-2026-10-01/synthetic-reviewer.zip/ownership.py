import sys,json
from pathlib import Path
repo=Path('/Users/shedrackeze/Desktop/CMU/INTRO DEEP LRNG/Project/Codex');sys.path[:0]=[str(repo/'src'),str(repo/'tests')]
from test_width_rate_recovery import source,module
base=Path('/private/tmp/width-rate-recovery-review-b2ef4b0/ownership');base.mkdir();v=source(base);root=base/'run';calls=[]
def guard():
 root.symlink_to(v['source_root'],target_is_directory=True)
 return v
out=module()._recover(v['config'],root,guard,lambda *a:calls.append(a))
r={'failure_reason':out['failure_reason'],'calls':calls,'wrote_into_unowned_source':(v['source_root']/'controller-failure.json').exists()}
(base.parent/'ownership-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
